# 🏥 Mediqueue — Smart Hospital Locator & Appointment Management System

> Reduce hospital waiting time. Find nearby hospitals. Digitize queue management.

![Mediqueue Banner](https://via.placeholder.com/900x300/2563eb/ffffff?text=Mediqueue+%E2%80%93+Smart+Hospital+Locator)

---

## 📁 Folder Structure

```
mediqueue/
├── frontend/
│   ├── index.html          ← Main single-page app
│   ├── css/
│   │   └── style.css       ← All styles
│   └── js/
│       └── app.js          ← All frontend logic
│
├── backend/
│   ├── app.py              ← Flask server entry point
│   ├── requirements.txt    ← Python dependencies
│   ├── uploads/            ← Uploaded medical reports
│   ├── database/
│   │   └── db.py           ← SQLite schema & connection
│   └── routes/
│       ├── auth.py         ← Login / Register / Profile
│       ├── hospitals.py    ← Nearby hospitals API
│       ├── appointments.py ← Book / view appointments
│       ├── queue.py        ← Queue status & update
│       └── reports.py      ← Upload & analyze reports
│
└── README.md
```

---

## 🚀 Features

| Feature | Description |
|---------|-------------|
| 🗺️ **Hospital Locator** | Google Maps + Geolocation to find nearby hospitals |
| 📅 **Appointment Booking** | Select hospital, doctor, date, time slot |
| 🔢 **Queue Management** | Auto queue number, live position, wait time |
| 🚨 **Emergency SOS** | Red button → nearest hospital + priority queue |
| 📄 **Report Upload** | PDF/Image upload with simulated AI extraction |
| 👤 **User Profile** | Store medical info, blood group, emergency contact |
| 📊 **Dashboard** | Stats cards, quick actions, recent appointments |

---

## 🛠️ Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | HTML5, CSS3, Vanilla JavaScript |
| Icons | Font Awesome 6 |
| Fonts | Google Fonts (Inter) |
| Map | Google Maps JavaScript API + Places API |
| Backend | Python 3.x + Flask |
| Database | SQLite (via Python sqlite3) |
| File Upload | Werkzeug (Flask built-in) |

---

## ⚙️ Setup Instructions

### Step 1 — Clone the Repository
```bash
git clone https://github.com/YOUR_USERNAME/mediqueue.git
cd mediqueue
```

### Step 2 — Frontend Setup (No install needed!)
The frontend is pure HTML/CSS/JS. Just open in browser:
```bash
# Option A: Direct open
open frontend/index.html

# Option B: Use VS Code Live Server extension
# Right-click index.html → Open with Live Server
```

### Step 3 — Backend Setup (Optional — for full API support)
```bash
cd backend

# Create virtual environment
python -m venv venv

# Activate
# Windows:
venv\Scripts\activate
# Mac/Linux:
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt

# Run the server
python app.py
```
Server starts at: **http://localhost:5000**

### Step 4 — Add Google Maps API Key
1. Go to [Google Cloud Console](https://console.cloud.google.com/)
2. Create a project → Enable **Maps JavaScript API** + **Places API**
3. Create API Key
4. In `frontend/index.html`, replace at the bottom:
```html
<!-- Replace YOUR_GOOGLE_MAPS_API_KEY with your actual key -->
src="https://maps.googleapis.com/maps/api/js?key=YOUR_GOOGLE_MAPS_API_KEY&..."
```

> **Without API Key:** The app still works fully — it shows a placeholder map and sample hospital data instead.

---

## 🌐 API Routes

### Auth
| Method | Route | Description |
|--------|-------|-------------|
| POST | `/api/auth/register` | Register new user |
| POST | `/api/auth/login` | Login user |
| PUT  | `/api/auth/profile/:id` | Update profile |

### Hospitals
| Method | Route | Description |
|--------|-------|-------------|
| GET | `/api/hospitals/nearby?lat=&lng=` | Get nearby hospitals by coordinates |
| GET | `/api/hospitals/all` | Get all hospitals |

### Appointments
| Method | Route | Description |
|--------|-------|-------------|
| POST | `/api/appointments/book` | Book appointment |
| GET  | `/api/appointments/user/:id` | Get user's appointments |
| PUT  | `/api/appointments/:id/status` | Update appointment status |

### Queue
| Method | Route | Description |
|--------|-------|-------------|
| GET  | `/api/queue/status?hospital=&department=` | Get queue status |
| POST | `/api/queue/update` | Update queue counter |

### Reports
| Method | Route | Description |
|--------|-------|-------------|
| POST | `/api/reports/upload` | Upload medical report |
| GET  | `/api/reports/user/:id` | Get user's uploaded reports |

---

## 🗄️ Database Schema

```sql
users        (id, name, email, phone, password, blood_group, dob, address, ...)
hospitals    (id, name, address, city, lat, lng, phone, rating, has_emergency, departments)
doctors      (id, name, department, hospital_id, available)
appointments (id, user_id, hospital, department, doctor, date, time, status, queue_number, ...)
queue        (id, hospital, department, now_serving, total_waiting, updated_at)
reports      (id, user_id, filename, filepath, extracted_issue, suggested_doctor, uploaded_at)
```

---

## 🧪 Sample Test Data

```json
// Login (any email + password works in demo mode)
{ "email": "test@example.com", "password": "test123" }

// Book Appointment
{
  "user_id": 1,
  "hospital": "Apollo Hospital",
  "department": "Cardiology",
  "doctor": "Dr. R.S. Gupta",
  "date": "2024-12-25",
  "time": "10:00 AM",
  "symptoms": "Chest pain"
}

// Upload Report
// POST /api/reports/upload (multipart/form-data)
// Field: file = your_report.pdf
// Field: user_id = 1
```

---

## 🎨 Design Colors

| Color | Hex | Usage |
|-------|-----|-------|
| Primary Blue | `#2563eb` | Navigation, buttons, primary actions |
| Success Green | `#16a34a` | Completed appointments, success toasts |
| Emergency Red | `#ef4444` | Emergency button, cancelled, alerts |
| Warning Orange | `#f97316` | Queue, warnings |

---

## 🔮 Future Improvements

1. **Real AI Report Analysis** — Integrate OCR + NLP to extract actual data from PDFs
2. **Doctor Availability Calendar** — Real-time slot availability
3. **SMS/Email Notifications** — Queue reminders via Twilio/SendGrid
4. **Admin Dashboard** — Hospital staff can manage queues from a separate panel
5. **Telemedicine** — Video consultation via WebRTC
6. **Insurance Integration** — Verify insurance coverage before booking
7. **Multi-language Support** — Hindi and other regional languages
8. **Mobile App** — Convert to PWA or build React Native version
9. **Payment Gateway** — Razorpay/Stripe for consultation fees
10. **Health Records** — Complete patient health history management

---

## 👨‍💻 Built by
**Anurag Tiwari** | Snapgo CTO | Sharda University, BTech IT 6A

---

## 📄 License
MIT License — Free to use and modify.
