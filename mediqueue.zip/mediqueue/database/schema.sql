-- ═══════════════════════════════════════════
-- MEDIQUEUE — DATABASE SCHEMA
-- SQLite
-- ═══════════════════════════════════════════

-- Users table
CREATE TABLE IF NOT EXISTS users (
    id               TEXT PRIMARY KEY,
    name             TEXT NOT NULL,
    email            TEXT UNIQUE NOT NULL,
    phone            TEXT,
    dob              TEXT,
    blood_group      TEXT,
    address          TEXT,
    emergency_contact TEXT,
    allergies        TEXT,
    created_at       DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Hospitals table
CREATE TABLE IF NOT EXISTS hospitals (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    name      TEXT NOT NULL,
    address   TEXT,
    phone     TEXT,
    latitude  REAL,
    longitude REAL,
    rating    REAL DEFAULT 4.0,
    type      TEXT DEFAULT 'General'
);

-- Appointments table
CREATE TABLE IF NOT EXISTS appointments (
    id           TEXT PRIMARY KEY,
    user_id      TEXT NOT NULL,
    hospital     TEXT NOT NULL,
    department   TEXT NOT NULL,
    doctor       TEXT NOT NULL,
    date         TEXT NOT NULL,
    time         TEXT NOT NULL,
    reason       TEXT,
    status       TEXT DEFAULT 'upcoming',
    queue_number TEXT,
    created_at   DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Reports table
CREATE TABLE IF NOT EXISTS reports (
    id             TEXT PRIMARY KEY,
    user_id        TEXT NOT NULL,
    filename       TEXT,
    filepath       TEXT,
    extracted_data TEXT,
    uploaded_at    DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- ─── Sample Hospital Data ───────────────────
INSERT OR IGNORE INTO hospitals (name, address, phone, latitude, longitude, rating, type) VALUES
('Apollo Hospital',        'Sarita Vihar, Delhi',   '011-29871234', 28.5355, 77.2759, 4.8, 'Multi-Speciality'),
('AIIMS Delhi',            'Ansari Nagar, Delhi',   '011-26588500', 28.5672, 77.2100, 4.9, 'Government'),
('Fortis Healthcare',      'Noida Sector 62',       '0120-4677777', 28.6273, 77.3648, 4.6, 'Multi-Speciality'),
('Max Super Speciality',   'Patparganj, Delhi',     '011-43006200', 28.6228, 77.2941, 4.7, 'Multi-Speciality'),
('Kailash Hospital',       'Sector 27, Noida',      '0120-4133333', 28.5706, 77.3219, 4.4, 'General'),
('Sharda Hospital',        'Greater Noida',          '0120-4600000', 28.4744, 77.5040, 4.3, 'General');
