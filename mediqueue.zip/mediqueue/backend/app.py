# ==============================
# MEDIQUEUE - app.py
# Flask Backend Server
# ==============================

from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
import os

from database.db import init_db
from routes.auth        import auth_bp
from routes.hospitals   import hospitals_bp
from routes.appointments import appointments_bp
from routes.queue       import queue_bp
from routes.reports     import reports_bp

app = Flask(__name__, static_folder='../frontend', static_url_path='')
CORS(app)  # Allow cross-origin requests from frontend

# ── Config ──────────────────────────────────────
app.config['SECRET_KEY']       = 'mediqueue-secret-2024'
app.config['UPLOAD_FOLDER']    = 'uploads'
app.config['MAX_CONTENT_LENGTH'] = 10 * 1024 * 1024  # 10MB max

# Create upload folder if not exists
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# ── Register Blueprints (route groups) ──────────
app.register_blueprint(auth_bp,          url_prefix='/api/auth')
app.register_blueprint(hospitals_bp,     url_prefix='/api/hospitals')
app.register_blueprint(appointments_bp,  url_prefix='/api/appointments')
app.register_blueprint(queue_bp,         url_prefix='/api/queue')
app.register_blueprint(reports_bp,       url_prefix='/api/reports')

# ── Serve Frontend ──────────────────────────────
@app.route('/')
def index():
    return send_from_directory('../frontend', 'index.html')

# ── Health Check ────────────────────────────────
@app.route('/api/health')
def health():
    return jsonify({'status': 'ok', 'message': 'Mediqueue API running'})

# ── Global Error Handlers ───────────────────────
@app.errorhandler(404)
def not_found(e):
    return jsonify({'error': 'Route not found'}), 404

@app.errorhandler(500)
def server_error(e):
    return jsonify({'error': 'Internal server error'}), 500

# ── Run ─────────────────────────────────────────
if __name__ == '__main__':
    init_db()                        # Create tables on first run
    app.run(debug=True, port=5000)
