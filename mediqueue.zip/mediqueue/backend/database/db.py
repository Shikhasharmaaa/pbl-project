# ==============================
# MEDIQUEUE - database/db.py
# SQLite Database Setup
# ==============================

import sqlite3
import os

DB_PATH = os.path.join(os.path.dirname(__file__), 'mediqueue.db')

def get_db():
    """Get a database connection."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row   # Returns dict-like rows
    return conn

def init_db():
    """Create all tables if they don't exist."""
    conn = get_db()
    c = conn.cursor()

    # ── Users Table ──────────────────────────────
    c.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            name        TEXT    NOT NULL,
            email       TEXT    UNIQUE NOT NULL,
            phone       TEXT,
            password    TEXT    NOT NULL,
            blood_group TEXT    DEFAULT 'O+',
            dob         TEXT,
            address     TEXT,
            emergency_contact TEXT,
            allergies   TEXT,
            created_at  TEXT    DEFAULT (datetime('now'))
        )
    ''')

    # ── Hospitals Table ───────────────────────────
    c.execute('''
        CREATE TABLE IF NOT EXISTS hospitals (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            name        TEXT    NOT NULL,
            address     TEXT,
            city        TEXT,
            lat         REAL,
            lng         REAL,
            phone       TEXT,
            rating      REAL    DEFAULT 4.0,
            has_emergency INTEGER DEFAULT 1,
            departments TEXT
        )
    ''')

    # ── Doctors Table ─────────────────────────────
    c.execute('''
        CREATE TABLE IF NOT EXISTS doctors (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            name        TEXT    NOT NULL,
            department  TEXT,
            hospital_id INTEGER,
            available   INTEGER DEFAULT 1,
            FOREIGN KEY (hospital_id) REFERENCES hospitals(id)
        )
    ''')

    # ── Appointments Table ────────────────────────
    c.execute('''
        CREATE TABLE IF NOT EXISTS appointments (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id      INTEGER NOT NULL,
            hospital     TEXT    NOT NULL,
            department   TEXT,
            doctor       TEXT,
            date         TEXT    NOT NULL,
            time         TEXT    NOT NULL,
            symptoms     TEXT,
            status       TEXT    DEFAULT 'upcoming',
            queue_number INTEGER,
            wait_time    INTEGER,
            is_emergency INTEGER DEFAULT 0,
            created_at   TEXT    DEFAULT (datetime('now')),
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    ''')

    # ── Queue Table ───────────────────────────────
    c.execute('''
        CREATE TABLE IF NOT EXISTS queue (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            hospital     TEXT    NOT NULL,
            department   TEXT,
            now_serving  INTEGER DEFAULT 1,
            total_waiting INTEGER DEFAULT 0,
            updated_at   TEXT    DEFAULT (datetime('now'))
        )
    ''')

    # ── Reports Table ─────────────────────────────
    c.execute('''
        CREATE TABLE IF NOT EXISTS reports (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id      INTEGER NOT NULL,
            filename     TEXT    NOT NULL,
            filepath     TEXT,
            file_type    TEXT,
            file_size    INTEGER,
            extracted_name  TEXT,
            extracted_issue TEXT,
            suggested_doctor TEXT,
            uploaded_at  TEXT    DEFAULT (datetime('now')),
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    ''')

    # ── Insert Sample Hospital Data ───────────────
    c.execute("SELECT COUNT(*) FROM hospitals")
    if c.fetchone()[0] == 0:
        hospitals = [
            ('Apollo Hospital',      'Sector 26, Noida',        'Noida',       28.5706, 77.3219, '0120-4600000', 4.5, 1, 'General,Cardiology,Orthopedics'),
            ('Fortis Hospital',      'Sector 62, Noida',        'Noida',       28.6271, 77.3726, '0120-2400000', 4.3, 1, 'General,Neurology,Pediatrics'),
            ('Max Super Speciality', 'Vaishali, Ghaziabad',     'Ghaziabad',   28.6439, 77.3380, '0120-4599999', 4.6, 1, 'Cardiology,ENT,Dermatology'),
            ('Kailash Hospital',     'Greater Noida',           'Gr. Noida',   28.4744, 77.5040, '0120-4555555', 4.1, 0, 'General,Gynecology'),
            ('Metro Hospital',       'Sector 12, Noida',        'Noida',       28.5826, 77.3116, '0120-2500000', 3.9, 0, 'General,Orthopedics'),
            ('Yatharth Hospital',    'Knowledge Park, Gr. Noida','Gr. Noida',  28.4665, 77.5099, '0120-4466000', 4.2, 1, 'General,Cardiology,Neurology'),
        ]
        c.executemany('''
            INSERT INTO hospitals (name,address,city,lat,lng,phone,rating,has_emergency,departments)
            VALUES (?,?,?,?,?,?,?,?,?)
        ''', hospitals)

    conn.commit()
    conn.close()
    print('✅ Database initialized successfully')
