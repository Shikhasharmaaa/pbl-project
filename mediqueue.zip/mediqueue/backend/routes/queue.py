# routes/queue.py
from flask import Blueprint, request, jsonify
from database.db import get_db

queue_bp = Blueprint('queue', __name__)

@queue_bp.route('/status', methods=['GET'])
def queue_status():
    hospital   = request.args.get('hospital', 'Apollo Hospital')
    department = request.args.get('department', 'General')
    db = get_db()
    q = db.execute('SELECT * FROM queue WHERE hospital=? AND department=?',
                   (hospital, department)).fetchone()
    if not q:
        db.execute('INSERT INTO queue (hospital,department,now_serving,total_waiting) VALUES (?,?,1,0)',
                   (hospital, department))
        db.commit()
        q = db.execute('SELECT * FROM queue WHERE hospital=? AND department=?',
                       (hospital, department)).fetchone()
    db.close()
    return jsonify(dict(q))

@queue_bp.route('/update', methods=['POST'])
def update_queue():
    data = request.get_json()
    db = get_db()
    db.execute('''UPDATE queue SET now_serving=?, total_waiting=?, updated_at=datetime('now')
                  WHERE hospital=? AND department=?''',
               (data['now_serving'], data['total_waiting'], data['hospital'], data['department']))
    db.commit(); db.close()
    return jsonify({'message': 'Queue updated'})
