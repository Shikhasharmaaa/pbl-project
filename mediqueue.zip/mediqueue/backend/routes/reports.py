# routes/reports.py
import os, random
from flask import Blueprint, request, jsonify
from werkzeug.utils import secure_filename
from database.db import get_db

reports_bp = Blueprint('reports', __name__)
ALLOWED = {'pdf', 'jpg', 'jpeg', 'png'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED

@reports_bp.route('/upload', methods=['POST'])
def upload():
    if 'file' not in request.files:
        return jsonify({'error': 'No file provided'}), 400
    file = request.files['file']
    uid  = request.form.get('user_id', 1)
    if file.filename == '' or not allowed_file(file.filename):
        return jsonify({'error': 'Invalid file type. Only PDF/JPG/PNG allowed'}), 400

    fname = secure_filename(file.filename)
    fpath = os.path.join('uploads', fname)
    file.save(fpath)

    # Simulated AI extraction
    issues  = ['Hypertension', 'Diabetes Type 2', 'Viral Fever', 'Back Pain', 'Migraine']
    doctors = ['Dr. A.K. Sharma (General)', 'Dr. R.S. Gupta (Cardiology)',
               'Dr. S.K. Jain (Orthopedics)', 'Dr. Priya Singh (General)']
    extracted_issue  = random.choice(issues)
    suggested_doctor = random.choice(doctors)

    db = get_db()
    db.execute('''INSERT INTO reports (user_id,filename,filepath,file_type,extracted_issue,suggested_doctor)
                  VALUES (?,?,?,?,?,?)''',
               (uid, fname, fpath, file.content_type, extracted_issue, suggested_doctor))
    db.commit()
    db.close()

    return jsonify({
        'message': 'Report uploaded and analyzed',
        'filename': fname,
        'extracted_issue': extracted_issue,
        'suggested_doctor': suggested_doctor
    }), 201

@reports_bp.route('/user/<int:user_id>', methods=['GET'])
def user_reports(user_id):
    db = get_db()
    reports = [dict(r) for r in db.execute(
        'SELECT * FROM reports WHERE user_id=? ORDER BY uploaded_at DESC', (user_id,)).fetchall()]
    db.close()
    return jsonify(reports)
