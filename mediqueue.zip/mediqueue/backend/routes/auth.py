# routes/auth.py
from flask import Blueprint, request, jsonify, session
from database.db import get_db
import hashlib

auth_bp = Blueprint('auth', __name__)

def hash_password(pw): return hashlib.sha256(pw.encode()).hexdigest()

@auth_bp.route('/register', methods=['POST'])
def register():
    data = request.get_json()
    name, email, phone, password = data.get('name'), data.get('email'), data.get('phone',''), data.get('password')
    if not all([name, email, password]):
        return jsonify({'error': 'Name, email and password required'}), 400
    db = get_db()
    try:
        db.execute('INSERT INTO users (name,email,phone,password) VALUES (?,?,?,?)',
                   (name, email, phone, hash_password(password)))
        db.commit()
        user = db.execute('SELECT id,name,email,phone FROM users WHERE email=?', (email,)).fetchone()
        return jsonify({'message': 'Registered successfully', 'user': dict(user)}), 201
    except Exception as e:
        return jsonify({'error': 'Email already exists'}), 409
    finally: db.close()

@auth_bp.route('/login', methods=['POST'])
def login():
    data = request.get_json()
    email, password = data.get('email'), data.get('password')
    db = get_db()
    user = db.execute('SELECT id,name,email,phone FROM users WHERE email=? AND password=?',
                      (email, hash_password(password))).fetchone()
    db.close()
    if not user: return jsonify({'error': 'Invalid credentials'}), 401
    return jsonify({'message': 'Login successful', 'user': dict(user)}), 200

@auth_bp.route('/profile/<int:user_id>', methods=['PUT'])
def update_profile(user_id):
    data = request.get_json()
    db = get_db()
    db.execute('''UPDATE users SET name=?,phone=?,blood_group=?,dob=?,address=?,emergency_contact=?,allergies=?
                  WHERE id=?''',
               (data.get('name'), data.get('phone'), data.get('blood_group'),
                data.get('dob'), data.get('address'), data.get('emergency_contact'),
                data.get('allergies'), user_id))
    db.commit(); db.close()
    return jsonify({'message': 'Profile updated'})
