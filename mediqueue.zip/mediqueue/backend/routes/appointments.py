# routes/appointments.py
from flask import Blueprint, request, jsonify
from database.db import get_db
import random

appointments_bp = Blueprint('appointments', __name__)

@appointments_bp.route('/book', methods=['POST'])
def book():
    data = request.get_json()
    queue_num = random.randint(5, 40)
    wait_time = queue_num * 8
    db = get_db()
    db.execute('''INSERT INTO appointments
        (user_id,hospital,department,doctor,date,time,symptoms,queue_number,wait_time,is_emergency)
        VALUES (?,?,?,?,?,?,?,?,?,?)''',
        (data['user_id'], data['hospital'], data.get('department',''), data.get('doctor',''),
         data['date'], data['time'], data.get('symptoms',''),
         queue_num, wait_time, data.get('is_emergency', 0)))
    db.commit()
    appt_id = db.execute('SELECT last_insert_rowid()').fetchone()[0]
    db.close()
    return jsonify({'message': 'Appointment booked', 'queue_number': queue_num,
                    'wait_time': wait_time, 'appointment_id': appt_id}), 201

@appointments_bp.route('/user/<int:user_id>', methods=['GET'])
def user_appointments(user_id):
    db = get_db()
    appts = [dict(a) for a in db.execute(
        'SELECT * FROM appointments WHERE user_id=? ORDER BY created_at DESC', (user_id,)).fetchall()]
    db.close()
    return jsonify(appts)

@appointments_bp.route('/<int:appt_id>/status', methods=['PUT'])
def update_status(appt_id):
    data = request.get_json()
    db = get_db()
    db.execute('UPDATE appointments SET status=? WHERE id=?', (data['status'], appt_id))
    db.commit(); db.close()
    return jsonify({'message': 'Status updated'})


# ── routes/queue.py ──────────────────────────────
from flask import Blueprint as BP
queue_bp = BP('queue', __name__)

@queue_bp.route('/status', methods=['GET'])
def queue_status():
    hospital   = request.args.get('hospital', 'Apollo Hospital')
    department = request.args.get('department', 'General')
    db = get_db()
    q = db.execute('SELECT * FROM queue WHERE hospital=? AND department=?',
                   (hospital, department)).fetchone()
    if not q:
        db.execute('INSERT INTO queue (hospital,department,now_serving,total_waiting) VALUES (?,?,1,0)',
                   (hospital, department))
        db.commit()
        q = db.execute('SELECT * FROM queue WHERE hospital=? AND department=?',
                       (hospital, department)).fetchone()
    db.close()
    return jsonify(dict(q))

@queue_bp.route('/update', methods=['POST'])
def update_queue():
    data = request.get_json()
    db = get_db()
    db.execute('''UPDATE queue SET now_serving=?, total_waiting=?, updated_at=datetime('now')
                  WHERE hospital=? AND department=?''',
               (data['now_serving'], data['total_waiting'], data['hospital'], data['department']))
    db.commit(); db.close()
    return jsonify({'message': 'Queue updated'})


# ── routes/reports.py ────────────────────────────
import os, random as rand
from flask import Blueprint as BP2, request as req, jsonify as jfy
from werkzeug.utils import secure_filename
from database.db import get_db as gdb

reports_bp = BP2('reports', __name__)
ALLOWED = {'pdf','jpg','jpeg','png'}

def allowed(filename):
    return '.' in filename and filename.rsplit('.',1)[1].lower() in ALLOWED

@reports_bp.route('/upload', methods=['POST'])
def upload():
    if 'file' not in req.files:
        return jfy({'error': 'No file provided'}), 400
    file  = req.files['file']
    uid   = req.form.get('user_id', 1)
    if file.filename == '' or not allowed(file.filename):
        return jfy({'error': 'Invalid file type'}), 400

    fname = secure_filename(file.filename)
    fpath = os.path.join('uploads', fname)
    file.save(fpath)

    # Simulated AI extraction
    issues   = ['Hypertension','Diabetes','Viral Fever','Back Pain','Migraine']
    doctors  = ['Dr. A.K. Sharma (General)','Dr. R.S. Gupta (Cardiology)',
                'Dr. S.K. Jain (Orthopedics)']
    extracted_issue   = rand.choice(issues)
    suggested_doctor  = rand.choice(doctors)

    db = gdb()
    db.execute('''INSERT INTO reports
        (user_id,filename,filepath,file_type,extracted_issue,suggested_doctor)
        VALUES (?,?,?,?,?,?)''',
        (uid, fname, fpath, file.content_type, extracted_issue, suggested_doctor))
    db.commit(); db.close()
    return jfy({'message':'Report uploaded','extracted_issue':extracted_issue,
                'suggested_doctor':suggested_doctor}), 201

@reports_bp.route('/user/<int:user_id>', methods=['GET'])
def user_reports(user_id):
    db = gdb()
    reports = [dict(r) for r in db.execute(
        'SELECT * FROM reports WHERE user_id=? ORDER BY uploaded_at DESC', (user_id,)).fetchall()]
    db.close()
    return jfy(reports)
