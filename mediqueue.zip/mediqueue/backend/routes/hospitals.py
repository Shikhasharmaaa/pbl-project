# routes/hospitals.py
from flask import Blueprint, jsonify, request
from database.db import get_db
import math

hospitals_bp = Blueprint('hospitals', __name__)

def haversine(lat1, lng1, lat2, lng2):
    R = 6371
    dlat = math.radians(lat2-lat1); dlng = math.radians(lng2-lng1)
    a = math.sin(dlat/2)**2 + math.cos(math.radians(lat1))*math.cos(math.radians(lat2))*math.sin(dlng/2)**2
    return round(R * 2 * math.atan2(math.sqrt(a), math.sqrt(1-a)), 1)

@hospitals_bp.route('/nearby', methods=['GET'])
def nearby():
    lat = float(request.args.get('lat', 28.4744))
    lng = float(request.args.get('lng', 77.5040))
    db = get_db()
    hospitals = db.execute('SELECT * FROM hospitals').fetchall()
    db.close()
    result = []
    for h in hospitals:
        d = haversine(lat, lng, h['lat'], h['lng'])
        result.append({**dict(h), 'distance_km': d})
    result.sort(key=lambda x: x['distance_km'])
    return jsonify(result)

@hospitals_bp.route('/all', methods=['GET'])
def all_hospitals():
    db = get_db()
    hospitals = [dict(h) for h in db.execute('SELECT * FROM hospitals').fetchall()]
    db.close()
    return jsonify(hospitals)
